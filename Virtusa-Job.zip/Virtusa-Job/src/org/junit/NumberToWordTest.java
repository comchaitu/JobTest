package org.junit;


import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import main.NumberToWord;

public class NumberToWordTest {

	  
	    @Test
	    public void testMain() throws Exception {
	        NumberToWord input = new NumberToWord();
	 
	        Scanner sc = new Scanner(System.in);
	        System.out.print("Enter Number:");
	        int number = sc.nextInt();
	        assertEquals("fifty seven", input.convert(number));
	        sc.close();
	    }
	}
